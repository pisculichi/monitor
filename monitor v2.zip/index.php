<!DOCTYPE html>
<html>
<head>

<title>Monitor</title>
<script language="javascript">
    window.location.href = "pages/login.php"
</script>
</head>
<body>
Go to <a href="pages/index.php">/pages/login.php</a>
</body>
</html>
